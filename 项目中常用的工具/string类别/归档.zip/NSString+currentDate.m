//
//  NSString+currentDate.m
//  AppNetTest4.11
//
//  Created by mc on 16/8/17.
//  Copyright © 2016年 LWJ. All rights reserved.
//

#import "NSString+currentDate.h"

@implementation NSString (currentDate)
+(NSString *)currentDate{

    NSDate *currentDate = [NSDate date];
    NSDateFormatter *dateFormatter = [[NSDateFormatter alloc]init];
    [dateFormatter setDateFormat:@"yyyyMMddHHmmss"];

    //将获取后的本地时间 转换成东八区时间
    dateFormatter.timeZone = [NSTimeZone timeZoneWithAbbreviation:@"GMT+0800"];
    NSString *dateStr = [dateFormatter stringFromDate:currentDate];
    return dateStr;
}

+(NSString *)getNowDate{
    
    NSDate *currentDate = [NSDate date];
    NSDateFormatter *dateFormatter = [[NSDateFormatter alloc]init];
    [dateFormatter setDateFormat:@"yyyy-MM-dd HH:mm:ss"];
    NSString *dateStr = [dateFormatter stringFromDate:currentDate];
    return dateStr;
}


@end
