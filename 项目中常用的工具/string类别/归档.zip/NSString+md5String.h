//
//  NSString+md5String.h
//  AppNetTest4.11
//
//  Created by mc on 16/8/4.
//  Copyright © 2016年 LWJ. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSString (md5String)
/** md5 一般加密 */
+ (NSString *)md5String:(NSString *)str;
/** md5 NB(牛逼的意思)加密*/
+ (NSString *)md5StringNB:(NSString *)str;

@end
