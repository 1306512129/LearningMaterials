//
//  UIImage+MyCostemImage.h
//  LWJProject
//
//  Created by mc on 2017/8/2.
//  Copyright © 2017年 LWJ. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIImage (MyCostemImage)
- (UIImage *)circleImage;
@end
