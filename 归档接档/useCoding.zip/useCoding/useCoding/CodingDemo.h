//
//  CodingDemo.h
//  useCoding
//
//  Created by 税鸽飞腾 on 2018/9/4.
//  Copyright © 2018年 LWJ. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface CodingDemo : NSObject<NSCoding>
@property (nonatomic,copy)NSString *name;
- (instancetype)initWithName:(NSString *)name;
@end
