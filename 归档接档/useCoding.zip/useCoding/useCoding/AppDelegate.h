//
//  AppDelegate.h
//  useCoding
//
//  Created by 税鸽飞腾 on 2018/9/4.
//  Copyright © 2018年 LWJ. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

