//
//  CodingDemo.m
//  useCoding
//
//  Created by 税鸽飞腾 on 2018/9/4.
//  Copyright © 2018年 LWJ. All rights reserved.
//

#import "CodingDemo.h"
#import <objc/runtime.h>
@implementation CodingDemo
- (instancetype)initWithName:(NSString *)name{
    
    self = [super init];
    if (self) {
        _name = name;
    }
    return self;
}
//归档
- (void)encodeWithCoder:(NSCoder *)aCoder{
    unsigned int count = 0;
    Ivar *ivarLists = class_copyIvarList([CodingDemo class],&count);
    
    for (int i = 0; i<=count; i++) {
        const char*name = ivar_getName(ivarLists[i]);
        NSString* stringName = [NSString stringWithCString:name encoding:NSUTF8StringEncoding];
        //利用KVC取值
        id value = [self valueForKey:stringName];
        [aCoder encodeObject:value forKey:stringName];
    }
    free(ivarLists);//释放
}
//接档
- (instancetype)initWithCoder:(NSCoder *)aDecoder{
    
    self = [super init];
    if (self) {
        unsigned int count = 0;
        Ivar *ivarLists = class_copyIvarList([CodingDemo class], &count);
        for (int i = 0; i<count; i++) {
            const char *name =ivar_getName(ivarLists[i]);
            NSString* stringName = [NSString stringWithCString:name encoding:NSUTF8StringEncoding];
            //进行解档取值
            id value = [aDecoder decodeObjectForKey:stringName];
            //利用KVC对属性赋值
            [self setValue:value forKey:stringName];
        }
        free(ivarLists);
    }
    return self;
}
@end
