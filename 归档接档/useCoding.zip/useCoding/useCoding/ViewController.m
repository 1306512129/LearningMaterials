//
//  ViewController.m
//  useCoding
//
//  Created by 税鸽飞腾 on 2018/9/4.
//  Copyright © 2018年 LWJ. All rights reserved.
//

#import "ViewController.h"
#import "CodingDemo.h"
#import "RACFileManager.h"
@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    //保存
    [self archiveObject];
    //取
    [self unArchiveObject];
}
- (void)archiveObject{
    
    CodingDemo *demoObj = [[CodingDemo alloc] init];
    
    NSString* cachePath = [RACFileManager cacheDirectory];
    NSString* fileName = @"Obj.data";
    NSString* filePath = [cachePath stringByAppendingPathComponent:fileName];
    
    NSMutableData *data = [NSMutableData data];
    NSKeyedArchiver *archiver = [[NSKeyedArchiver alloc] initForWritingWithMutableData:data];
    [archiver setRequiresSecureCoding:YES];
    [archiver encodeObject:demoObj forKey:NSKeyedArchiveRootObjectKey];
    [archiver finishEncoding];
    [data writeToFile:filePath atomically:YES];
   
}
- (void)unArchiveObject{
    NSString* cachePath = [RACFileManager cacheDirectory];
    NSString* fileName = @"Obj.data";
    NSString* filePath = [cachePath stringByAppendingPathComponent:fileName];
    NSData* archivedData = [[NSData alloc]initWithContentsOfFile:filePath];
    NSKeyedUnarchiver *unarchiver = [[NSKeyedUnarchiver alloc] initForReadingWithData:archivedData];
    [unarchiver setRequiresSecureCoding:YES];
    CodingDemo *demoObj = [unarchiver decodeObjectOfClass:[CodingDemo class] forKey:NSKeyedArchiveRootObjectKey];
    NSLog(@"%@",demoObj.name);
   
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
