//
//  LWJTabBarController.m
//  ProjectDemo
//
//  Created by 税鸽飞腾 on 2018/9/29.
//  Copyright © 2018年 LWJ. All rights reserved.
//
#define ColorWithRGB(r, g, b)       [UIColor colorWithRed:(r)/255.f green:(g)/255.f blue:(b)/255.f alpha:1.f]

#define NavColor            ColorWithRGB(27, 114, 229)

#import "LWJTabBarController.h"
#import "LWJNavigationController.h"
#import "OneVC.h"
#import "TwoVC.h"
#import "ThreeVC.h"
@interface LWJTabBarController ()

@end

@implementation LWJTabBarController

- (void)viewDidLoad {
    [super viewDidLoad];
    
        //添加子导航控制器
    
    [self addChildViewController:[OneVC new] WithBottomTitle:@"首页" TopTitle:@"首页" UnselectedImgName:@"首页" SelectedImgName:@"首页灰色"];
    [self addChildViewController:[TwoVC new] WithBottomTitle:@"消息" TopTitle:@"消息" UnselectedImgName:@"消息" SelectedImgName:@"消息灰色"];
    [self addChildViewController:[ThreeVC new] WithBottomTitle:@"我" TopTitle:@"我" UnselectedImgName:@"我" SelectedImgName:@"我灰色"];
   
    
}
/**
 * 添加子导航控制器
 */
- (void)addChildViewController:(UIViewController *)childController WithBottomTitle:(NSString *)bottomTitle TopTitle:(NSString *)topTitle UnselectedImgName:(NSString *)unselectedImgName SelectedImgName:(NSString *)selectedImgName
{
    //新建导航条
    LWJNavigationController *nav = [LWJNavigationController new];
    [nav addChildViewController:childController];
    
    //修改导航条属性
    //图片
    nav.tabBarItem.image = [UIImage imageNamed:selectedImgName];
    //选中图片
    nav.tabBarItem.selectedImage = [UIImage imageNamed:unselectedImgName];
    //底部标题
    nav.tabBarItem.title = bottomTitle;
    //顶部标题
    childController.navigationItem.title = topTitle;
    
    NSMutableDictionary *atrr = [NSMutableDictionary dictionary];
    atrr[NSForegroundColorAttributeName] = [UIColor whiteColor];
    atrr[NSFontAttributeName] = [UIFont systemFontOfSize:20];
    //顶部字体颜色和大小
    [nav.navigationBar setTitleTextAttributes:atrr];
    
    //    //添加导航条背景图
    //    [nav.navigationBar setBackgroundImage:[UIImage imageNamed:@"nav"]  forBarMetrics:UIBarMetricsDefault];
    //导航条颜色
    [nav.navigationBar setBarTintColor:NavColor];
    [nav.navigationBar setShadowImage:[UIImage new]];
    
    //这行代码可以关闭半透明效果，但是会导致坐标0点移动。
    nav.navigationBar.translucent = NO;
    
    //添加为子导航控制器
    [self addChildViewController:nav];
    //修改tabbar上字体颜色
//    self.tabBar.tintColor = NavColor;
    
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
