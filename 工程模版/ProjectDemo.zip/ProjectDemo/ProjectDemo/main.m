//
//  main.m
//  ProjectDemo
//
//  Created by 税鸽飞腾 on 2018/9/29.
//  Copyright © 2018年 LWJ. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
